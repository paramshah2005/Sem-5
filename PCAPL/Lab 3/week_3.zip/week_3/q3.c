#include <stdio.h>
#include <omp.h>

#define N 100

int isPrime(int n)
{
    int i;

    if(n < 2)
        return 0;

    for(i = 2; i < n; i++)
    {
        if(n % i == 0)
            return 0;
    }

    return 1;
}

int main()
{
    int i;
    int count = 0;
    int thread_id[N + 1];
    double start, end;

    start = omp_get_wtime();

    #pragma omp parallel for schedule(static) reduction(+:count)
    for(i = 1; i <= N; i++)
    {
        thread_id[i] = omp_get_thread_num();

        if(isPrime(i))
            count++;
    }

    end = omp_get_wtime();

    printf("STATIC SCHEDULING\n");
    printf("Number of primes = %d\n", count);
    printf("Execution time = %f seconds\n", end - start);

    for(i = 1; i <= N; i++)
        printf("%d -> Thread %d\n", i, thread_id[i]);

    return 0;
}
