#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define N 1000000

int main()
{
    int a[N];
    int hist[10] = {0};
    int i;

    for(i = 0; i < N; i++)
        a[i] = rand() % 10;

    double start = omp_get_wtime();

    #pragma omp parallel for
    for(i = 0; i < N; i++)
    {
        #pragma omp atomic
        hist[a[i]]++;
    }

    double end = omp_get_wtime();

    printf("Parallel Histogram\n");

    for(i = 0; i < 10; i++)
        printf("%d : %d\n", i, hist[i]);

    printf("Execution Time = %f seconds\n",
           end - start);

    return 0;
}
