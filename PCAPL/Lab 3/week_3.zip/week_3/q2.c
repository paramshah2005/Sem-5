#include <stdio.h>
#include <omp.h>

#define N 10

int main()
{
    int a[N];
    int sum = 0;
    int even = 0;
    int i;

    #pragma omp parallel
    {
        // Master initializes the array
        #pragma omp master
        {
            for(i = 0; i < N; i++)
                a[i] = i + 1;

            printf("Number of threads = %d\n",
                   omp_get_num_threads());
        }

        #pragma omp barrier

        // Reduction for sum
        #pragma omp for reduction(+:sum)
        for(i = 0; i < N; i++)
        {
            sum += a[i];
        }

        // Atomic for counting even numbers
        #pragma omp for
        for(i = 0; i < N; i++)
        {
            if(a[i] % 2 == 0)
            {
                #pragma omp atomic
                even++;
            }
        }

        // Critical for displaying thread information
        #pragma omp for
        for(i = 0; i < N; i++)
        {
            #pragma omp critical
            {
                printf("Thread %d processed a[%d] = %d\n",
                       omp_get_thread_num(), i, a[i]);
            }
        }
    }

    printf("\nFinal Sum = %d\n", sum);
    printf("Total Even Numbers = %d\n", even);

    return 0;
}
