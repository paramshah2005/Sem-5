#include <stdio.h>
#include <omp.h>

int main()
{
    int i, sum;

    // 1. SHARED
    sum = 0;

    #pragma omp parallel for shared(sum)
    for(i = 1; i <= 10; i++)
    {
        sum = sum + i;
    }

    printf("Using shared: %d\n", sum);


    // 2. PRIVATE
    sum = 0;

    #pragma omp parallel for private(sum)
    for(i = 1; i <= 10; i++)
    {
        sum = sum + i;
    }

    printf("Using private: %d\n", sum);


    // 3. FIRSTPRIVATE
    sum = 0;

    #pragma omp parallel for firstprivate(sum)
    for(i = 1; i <= 10; i++)
    {
        sum = sum + i;
    }

    printf("Using firstprivate: %d\n", sum);


    // 4. LASTPRIVATE
    sum = 0;

    #pragma omp parallel for lastprivate(sum)
    for(i = 1; i <= 10; i++)
    {
        sum = sum + i;
    }

    printf("Using lastprivate: %d\n", sum);

    return 0;
}
