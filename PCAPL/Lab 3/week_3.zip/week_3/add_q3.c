#include <stdio.h>
#include <omp.h>

#define N 20

int main()
{
    long long fact;
    int i;

    // Critical
    fact = 1;

    #pragma omp parallel for
    for(i = 1; i <= N; i++)
    {
        #pragma omp critical
        {
            fact = fact * i;
        }
    }

    printf("Critical  = %lld\n", fact);


    // Atomic
    fact = 1;

    #pragma omp parallel for
    for(i = 1; i <= N; i++)
    {
        #pragma omp atomic
        fact = fact * i;
    }

    printf("Atomic    = %lld\n", fact);


    // Reduction
    fact = 1;

    #pragma omp parallel for reduction(*:fact)
    for(i = 1; i <= N; i++)
    {
        fact = fact * i;
    }

    printf("Reduction = %lld\n", fact);


    // Master
    fact = 1;

    #pragma omp parallel
    {
        #pragma omp master
        {
            for(i = 1; i <= N; i++)
                fact = fact * i;
        }
    }

    printf("Master    = %lld\n", fact);


    // Lock
    fact = 1;

    omp_lock_t lock;
    omp_init_lock(&lock);

    #pragma omp parallel for
    for(i = 1; i <= N; i++)
    {
        omp_set_lock(&lock);

        fact = fact * i;

        omp_unset_lock(&lock);
    }

    omp_destroy_lock(&lock);

    printf("Lock      = %lld\n", fact);

    return 0;
}