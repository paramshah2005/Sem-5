#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

void merge(int a[], int left, int mid, int right)
{
    int temp[1000];
    int i = left;
    int j = mid + 1;
    int k = left;

    while(i <= mid && j <= right)
    {
        if(a[i] < a[j])
            temp[k++] = a[i++];
        else
            temp[k++] = a[j++];
    }

    while(i <= mid)
        temp[k++] = a[i++];

    while(j <= right)
        temp[k++] = a[j++];

    for(i = left; i <= right; i++)
        a[i] = temp[i];
}

void mergeSort(int a[], int left, int right)
{
    if(left < right)
    {
        int mid = (left + right) / 2;

        mergeSort(a, left, mid);
        mergeSort(a, mid + 1, right);

        merge(a, left, mid, right);
    }
}

void parallelMergeSort(int a[], int left, int right)
{
    if(left < right)
    {
        int mid = (left + right) / 2;

        #pragma omp task
        parallelMergeSort(a, left, mid);

        #pragma omp task
        parallelMergeSort(a, mid + 1, right);

        #pragma omp taskwait

        merge(a, left, mid, right);
    }
}

int main()
{
    int a[1000], b[1000];
    int n = 1000;
    int i;

    for(i = 0; i < n; i++)
    {
        a[i] = rand() % 1000;
        b[i] = a[i];
    }

    double start, end;

    // Sequential
    start = omp_get_wtime();

    mergeSort(a, 0, n - 1);

    end = omp_get_wtime();

    double sequential_time = end - start;

    // Parallel
    start = omp_get_wtime();

    #pragma omp parallel
    {
        #pragma omp single
        parallelMergeSort(b, 0, n - 1);
    }

    end = omp_get_wtime();

    double parallel_time = end - start;

    double speedup = sequential_time / parallel_time;
    double efficiency =
        speedup / omp_get_max_threads();

    printf("Sequential Time = %f seconds\n", sequential_time);
    printf("Parallel Time   = %f seconds\n", parallel_time);
    printf("Speedup         = %f\n", speedup);
    printf("Efficiency      = %f\n", efficiency);

    return 0;
}
