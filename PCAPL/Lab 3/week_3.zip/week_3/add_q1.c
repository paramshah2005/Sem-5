#include <stdio.h>
#include <string.h>
#include <omp.h>

#define MAX_LINES 100
#define MAX_LENGTH 200

int main()
{
    FILE *fp;
    char lines[MAX_LINES][MAX_LENGTH];
    int n = 0;

    fp = fopen("input.txt", "r");

    if (fp == NULL)
    {
        printf("Error: input.txt not found\n");
        return 1;
    }

    // Read all lines from file
    while (fgets(lines[n], MAX_LENGTH, fp) != NULL)
    {
        n++;

        if (n == MAX_LINES)
            break;
    }

    fclose(fp);

    #pragma omp parallel
    {
        int tid = omp_get_thread_num();
        int threads = omp_get_num_threads();
        int i;

        // Round-robin assignment
        for (i = tid; i < n; i = i + threads)
        {
            char line[MAX_LENGTH];
            char *token;
            char *saveptr;

            strcpy(line, lines[i]);

            #pragma omp critical
            {
                printf("\nThread %d processing line %d:\n", tid, i);

                token = strtok_r(line, " \t\n", &saveptr);

                while (token != NULL)
                {
                    printf("%s\n", token);
                    token = strtok_r(NULL, " \t\n", &saveptr);
                }
            }
        }
    }

    return 0;
}