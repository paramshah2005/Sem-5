#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

#define N 10000000

int main()
{
    long long inside = 0;
    int i;

    double start = omp_get_wtime();

    #pragma omp parallel
    {
        long long local_inside = 0;
        unsigned int seed = time(NULL) + omp_get_thread_num();

        #pragma omp for
        for(i = 0; i < N; i++)
        {
            double x = (double)rand_r(&seed) / RAND_MAX;
            double y = (double)rand_r(&seed) / RAND_MAX;

            if(x * x + y * y <= 1.0)
                local_inside++;
        }

        #pragma omp atomic
        inside += local_inside;
    }

    double pi = 4.0 * inside / N;

    double end = omp_get_wtime();

    printf("Estimated PI = %f\n", pi);
    printf("Execution Time = %f seconds\n",
           end - start);

    return 0;
}